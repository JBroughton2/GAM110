﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //movement variables
    public float MaxSpeed = 2;
    public int BalloonsLeft = 5;
    public GameObject gameOverui;
    private float move;
    private bool FacingRight;
    private Rigidbody2D myrb;
    

    // Start is called before the first frame update
    void Start()
    {
        myrb = GetComponent<Rigidbody2D>();
        FacingRight = true;

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //Moving around
        move = Input.GetAxis("Horizontal");
        myrb.velocity = new Vector2(move * MaxSpeed, BalloonsLeft);


        //changing facing direction
        if (move > 0 && !FacingRight)
        {
            flip();
        }
        else if (move < 0 && FacingRight)
        {
            flip();
        }

        if(BalloonsLeft == 0)
        {
            myrb.gravityScale = 100;
            StartCoroutine(DeathDelay());
        }
    }

    void flip()
    {
        FacingRight = !FacingRight;
        Vector3 TheScale = transform.localScale;
        TheScale.x *= -1;
        transform.localScale = TheScale;
    }

    IEnumerator DeathDelay()
    {
        yield return new WaitForSeconds(3);
        Time.timeScale = 0;
        gameOverui.SetActive(true);
        
    }

}
