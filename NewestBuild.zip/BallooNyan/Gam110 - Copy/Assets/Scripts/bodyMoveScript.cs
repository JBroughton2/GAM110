﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bodyMoveScript : MonoBehaviour
{
    public Animator animator1;
    public static bool treatDistanceReset = false;
    private float maxRange = 11.01f;
    private float dist;

    void Update()
    {
        if (treatTester.treatDistance == true)
        {
            animator1.SetFloat("isAttracted", 1);

            GameObject[] treatsDetected;

            treatsDetected = GameObject.FindGameObjectsWithTag("Treat");
            GameObject closestTreat = null;
            float distance = Mathf.Infinity;
            Vector3 position = transform.position;

            foreach (GameObject treats in treatsDetected)
            {
                Vector3 diff = treats.transform.position - position;
                float curDistance = diff.sqrMagnitude;
                if(curDistance < distance)
                {
                    closestTreat = treats;
                    distance = curDistance;
                }
            }

            if (treatsDetected.Length == 0)
            {
                treatDistanceReset = true;
            }

            dist = Vector3.Distance(closestTreat.transform.position, transform.position);
            if (dist >= maxRange)
            {
                treatDistanceReset = true;
            }
        }

        else
        {
            animator1.SetFloat("isAttracted", 0);

        }
    }
}
