﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class treatCollector : MonoBehaviour
{
    public int numTreats = 0;
    public bool isMeowingTime = false;
    public headMoveScript pControl;
    public fishCounter pControl2;
    public PlayerController pControl3;
    public Transform Ballons1;
    private int balloonType;

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Treat"))
        {
            Destroy(col.gameObject);
            numTreats = numTreats + 1;
            isMeowingTime = true;

        }
    }

    private void Update()
    {
        if (pControl.completeMeow == true)
        {
            isMeowingTime = false;
        }

        if(pControl2.fiveFish == true)
        {

                var addBalloon = Instantiate(Ballons1, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
                addBalloon.transform.parent = gameObject.transform;
                pControl3.BalloonsLeft = pControl3.BalloonsLeft + 1;
                numTreats = 0;
                pControl2.fiveFish = false;


        }
    }

}
