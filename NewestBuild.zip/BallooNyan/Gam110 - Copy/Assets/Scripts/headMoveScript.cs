﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class headMoveScript : MonoBehaviour
{
    public Animator animator2;
    public treatCollector pControl;
    public bool completeMeow = false;

    void Update()
    {
        if (pControl.isMeowingTime == true)
        {
            animator2.SetFloat("isMeowing", 1);
            completeMeow = true;
        }

        else
        {
            animator2.SetFloat("isMeowing", 0);
        }


    }
}
