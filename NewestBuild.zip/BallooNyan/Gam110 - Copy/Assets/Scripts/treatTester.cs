﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class treatTester : MonoBehaviour
{
    private GameObject PlayerObj;
    private float dist;
    private float minDist = 11f;
    public static bool treatDistance = false;

    void Start()
    {
        PlayerObj = GameObject.FindGameObjectWithTag("Player");

    }


    void Update()
    {
        dist = Vector3.Distance(PlayerObj.transform.position, transform.position);
        if (dist <= minDist)
        {
            treatDistance = true;

        }
        
        if (bodyMoveScript.treatDistanceReset == true)
        {
            treatDistance = false;
        }
    }
}
